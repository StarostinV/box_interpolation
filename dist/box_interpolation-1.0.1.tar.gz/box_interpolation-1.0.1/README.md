# Box interpolation

One-function package for fast box interpolation powered by Cython.

Made for interpolating arbitrarily located 2D data to 2D grid.

### Installation

Install via pip:

```sh
pip install box_interpolation
```


